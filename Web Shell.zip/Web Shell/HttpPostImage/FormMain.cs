﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace HttpPostImage
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            // Read file data
            var fs = new FileStream("test.php", FileMode.Open, FileAccess.Read);
            var data = new byte[fs.Length];
            fs.Read(data, 0 , data.Length);
            fs.Close();

            // Generate post objects
            var postParameters = new Dictionary<string, object>
            {
                {"fileToUpload", new FormUpload.FileParameter(data, "test.php", "application/php")}
            };

            // Create request and receive response
            var postURL = "http://192.168.164.128/project/upload.php";
            var userAgent = "NRTechnology";
            var webResponse = FormUpload.MultipartFormDataPost(postURL, userAgent, postParameters);

            // Process response
            var responseReader = new StreamReader(webResponse.GetResponseStream() ?? throw new InvalidOperationException());
            var fullResponse = responseReader.ReadToEnd();
            webResponse.Close();
            MessageBox.Show(fullResponse);
            //Response.Write(fullResponse);
        }
    }
}
